#include <iostream>
#include <queue>
#include <vector>
using namespace std;

vector<vector<int>> reconstructQueue(vector<vector<int>>& people) {
    queue<vector<int>> q;
    for (auto person : people) {
        q.push(person);
    }

    vector<vector<int>> result;
    while (!q.empty()) {
        vector<int> person = q.front();
        q.pop();
        int height = person[0];
        int count = person[1];
        int pos = 0;
        for (auto it = result.begin(); it!= result.end(); ++it) {
            if ((*it)[0] >= height) {
                count--;
            }
            if (count == 0) {
                result.insert(it, person);
                break;
            }
            pos++;
        }
        if (count > 0) {
            result.push_back(person);
        }
    }

    return result;
}

int main() {
    vector<vector<int>> people = {{7, 0}, {4, 4}, {7, 1}, {5, 0}, {6, 1}, {5, 2}};
    vector<vector<int>> result = reconstructQueue(people);

    for (auto person : result) {
        cout << "[" << person[0] << ", " << person[1] << "] ";
    }
    cout << endl;

    return 0;
}
