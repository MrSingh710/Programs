#include <iostream>
#include <queue>
using namespace std;

void getBin(int n) {
    queue<string> q;
    q.push("");

    int count = 0;
    while (!q.empty() && count < n) {
        string binaryNumber = q.front();
        q.pop();

        if (binaryNumber.length() < n) {
            q.push(binaryNumber + "0");
            q.push(binaryNumber + "1");
        } else {
            cout << binaryNumber << " ";
            count++;
        }
    }
}

int main() {
    int n;
    cout << "Enter the value of n :  ";
    cin >> n;
    getBin(n);
    return 0;
}