public class Q09 {
    
}
